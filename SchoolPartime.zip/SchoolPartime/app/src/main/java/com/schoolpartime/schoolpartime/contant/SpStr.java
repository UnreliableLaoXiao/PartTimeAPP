package com.schoolpartime.schoolpartime.contant;

/**
 * Created by machenike on 2018/10/15.
 * 用于记录每次产生的新的存储字段
 */

public class SpStr {




}
