package com.schoolpartime.schoolpartime.net.request;

import com.schoolpartime.schoolpartime.entity.baseModel.ResultModel;
import com.schoolpartime.schoolpartime.net.request.base.RequestFactory;
import com.schoolpartime.schoolpartime.net.request.base.RequestResult;

import retrofit2.Retrofit;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class HttpRequest {

    public static Retrofit builder(){
        return RequestFactory.getInstance().Build(RequestFactory.TYPE.ALL);
    }

    public static Retrofit builder(RequestFactory.TYPE type){
        return RequestFactory.getInstance().Build(type);
    }

    public static void request(Observable observable, final RequestResult result){
        observable
                .subscribeOn(Schedulers.io())//IO线程加载数据
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ResultModel>() {
                    @Override
                    public void onCompleted() {}

                    @Override
                    public void onError(Throwable e) {
                        result.fail(e);
                    }

                    @Override
                    public void onNext(ResultModel resultModel) {
                        result.success(resultModel);
                    }
                });
    }



}
