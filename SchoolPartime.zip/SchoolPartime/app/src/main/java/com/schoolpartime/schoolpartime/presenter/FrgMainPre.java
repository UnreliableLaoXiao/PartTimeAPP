package com.schoolpartime.schoolpartime.presenter;

import android.animation.ValueAnimator;
import android.databinding.ViewDataBinding;
import android.graphics.Color;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.jude.rollviewpager.hintview.ColorPointHintView;
import com.schoolpartime.schoolpartime.R;
import com.schoolpartime.schoolpartime.SuperActivity;
import com.schoolpartime.schoolpartime.activity.LoginActivity;
import com.schoolpartime.schoolpartime.adapter.LoopAdapter;
import com.schoolpartime.schoolpartime.adapter.RecyclerAdapter;
import com.schoolpartime.schoolpartime.databinding.FragmentMainBinding;
import com.schoolpartime.schoolpartime.util.sp.SpCommonUtils;

public class FrgMainPre implements Presenter,NestedScrollView.OnScrollChangeListener, SwipeRefreshLayout.OnRefreshListener {

    private FragmentMainBinding binding;
    private SuperActivity activity;
    private int mscrollY;
    private boolean isLogin;
    private boolean isScroll = false;

    @Override
    public void attach(ViewDataBinding binding, SuperActivity activity) {
        this.binding = (FragmentMainBinding) binding;
        this.activity = activity;
        init();

    }

    private void init() {
        setRefresh();
        openRollPageView();
        binding.fgMainScroll.setOnScrollChangeListener(this);
        binding.rcyShow.setNestedScrollingEnabled(false);
        binding.rcyShow.setLayoutManager(new LinearLayoutManager(activity));
        binding.rcyShow.setAdapter(new RecyclerAdapter(activity, new RecyclerAdapter.MyOnItemClickListener() {   //设置adapter
            @Override
            public void onItemClick(View view) {
                /**
                 * 进入兼职详情页面
                 */
            }

            @Override
            public void onItemLongClick(View view) {
                /**
                 * 长按操作兼职列表
                 */
            }
        }));
    }

    @Override
    public void notifyUpdate(int code) {
        switch (code) {
            case 0:{
                isLogin = SpCommonUtils.getIsLogin(activity);
                if (isLogin) {
                    binding.goLogin.setText("我订阅的职位");
                } else {
                    binding.goLogin.setText("立即登录");
                }
            }
            break;
            case 1:{
                if (isScroll)
                scroll_Start();
            }
            default:
                break;
        }
    }

    private void scroll_Start() {
        ValueAnimator valueAnimator = ValueAnimator.ofInt(mscrollY,0);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int value = (int) animation.getAnimatedValue();
                binding.fgMainScroll.scrollTo(0,value);
            }
        });
        valueAnimator.setDuration(1000);
        valueAnimator.start();
    }

    private void setRefresh() {
        binding.swipeLayout.setOnRefreshListener(this);
        //设置样式刷新显示的位置
        binding.swipeLayout.setProgressViewOffset(true, -10, 50);
        binding.swipeLayout.setColorSchemeResources(R.color.swiperefresh_color1, R.color.swiperefresh_color2, R.color.swiperefresh_color3, R.color.swiperefresh_color4);
    }

    private void openRollPageView() {
        LoopAdapter contentAdapter=new LoopAdapter(binding.rollviewpager);
        binding.rollviewpager.setAdapter(contentAdapter);
        binding.rollviewpager.setPlayDelay(3000);
        binding.rollviewpager.setHintView(new ColorPointHintView(activity, Color.RED, Color.GRAY));
    }

    @Override
    public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
        mscrollY = scrollY;
        if(scrollY > 800){
            isScroll = true;
        }
        if (scrollY < 20){
            isScroll = false;
        }
    }

    @Override
    public void onRefresh() {
        /**
         * 逻辑
         */
        binding.swipeLayout.setRefreshing(false);
    }

    public void onClick(View view){
        if (!isLogin){
            (new LoginActivity()).inToActivity(activity);
        }else {
            /**
             * 职位选择
             */
        }
    }
}
