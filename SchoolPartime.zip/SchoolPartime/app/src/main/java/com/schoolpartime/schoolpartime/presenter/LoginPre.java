package com.schoolpartime.schoolpartime.presenter;

import android.databinding.ViewDataBinding;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;

import com.schoolpartime.schoolpartime.SuperActivity;
import com.schoolpartime.schoolpartime.databinding.ActivityLoginBinding;
import com.schoolpartime.schoolpartime.databinding.ActivityRegisterBinding;
import com.schoolpartime.schoolpartime.entity.User;
import com.schoolpartime.schoolpartime.entity.baseModel.ResultModel;
import com.schoolpartime.schoolpartime.listener.TextChangedListener;
import com.schoolpartime.schoolpartime.net.interfacz.UserLoginServer;
import com.schoolpartime.schoolpartime.net.request.HttpRequest;
import com.schoolpartime.schoolpartime.net.request.base.RequestResult;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LoginPre implements Presenter, View.OnClickListener {

    private String TAG = "LoginPre";

    private ActivityLoginBinding binding;
    private SuperActivity activity;

    @Override
    public void attach(ViewDataBinding binding, SuperActivity activity) {
        this.binding = (ActivityLoginBinding) binding;
        this.activity = activity;
        init();
    }

    private void init() {
        binding.etLgUsername.addTextChangedListener(textChangedListener);
        binding.etLgPsw.addTextChangedListener(textChangedListener);
        binding.submitLogin.setOnClickListener(this);
    }

    @Override
    public void notifyUpdate(int code) {
        switch (code) {
            case 1:{
                binding.submitLogin.setEnabled(true);
            }
            break;
            case 2:{
                binding.submitLogin.setEnabled(false);
            }
            default:
                break;
        }
    }

    private TextChangedListener textChangedListener =  new TextChangedListener(){
        @Override
        public void afterTextChange() {
            notifyUpdate(getEditIsFill()?1:2);
        }
    };

    private boolean getEditIsFill(){
        return Objects.requireNonNull(binding.etLgUsername.getText()).toString().length() > 0 && Objects.requireNonNull(binding.etLgPsw.getText()).toString().length() >0;
    }

    private void showResult(String mes) {
        Snackbar.make(binding.rly, mes, Snackbar.LENGTH_LONG)
                .setDuration(Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void onClick(View v) {
        activity.show("正在登陆...");
        HttpRequest.request(HttpRequest.builder().create(UserLoginServer.class).registerUser(getRequestBody()),
                new RequestResult() {
                    @Override
                    public void success(ResultModel resultModel) {
                        Log.d(TAG, "success: ");
                        activity.dismiss();
                        if (resultModel.code == 200) {
                            User user = (User) resultModel.data;
                            showResult(user.getUsername());
                        } else {
                            showResult(resultModel.message);
                        }
                    }

                    @Override
                    public void fail(Throwable e) {
                        e.printStackTrace();
                        Log.d(TAG, "failed: ",e);
                        activity.dismiss();
                        showResult("请求失败");
                    }
                });
    }

    private Map<String,String> getRequestBody() {
        Map<String,String> body = new HashMap<>();
        body.put("username",Objects.requireNonNull(binding.etLgUsername.getText()).toString());
        body.put("password",Objects.requireNonNull(binding.etLgPsw.getText()).toString());
        return body;
    }
}
