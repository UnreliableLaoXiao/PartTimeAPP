package com.example.updateapp.minterface;

/**
 * Created by machenike on 2018/10/16.
 */

public interface EndInterface {
    void Failed(int code);
}
