package com.example.updateapp.minterface;

/**
 * Created by machenike on 2018/10/16.
 */

public interface NetInterface {

    void complied(Object o);

    void progress(int mprogress);

    void fail();

}
